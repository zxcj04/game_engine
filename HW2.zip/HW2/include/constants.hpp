#pragma once

enum SCENE
{
    FIRST, ORTHO_X, ORTHO_Y, ORTHO_Z
};